package com.vogella.android.test1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class ProductActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.productlist);

        String[] products = {"Shirts", "Pants", "Shoes", "Accessories"};

        ArrayAdapter adapter = new ArrayAdapter<String>(this, R.layout.productlist, products);

        ListView productList = (ListView)
                findViewById(R.id.p_list);
        productList.setAdapter(adapter);
    }
}