package com.vogella.android.test1;

import android.widget.EditText;

public class Registerhelper {

    private final EditText id;
    private final EditText name;
    private final EditText email;
    private final EditText phone;
    private final EditText password;

    public Registerhelper(Register activity) {

        id = (EditText)
        activity.findViewById(R.id.id);
        name = (EditText)
                activity.findViewById(R.id.name);
        email = (EditText)
                activity.findViewById(R.id.email);
        phone = (EditText)
                activity.findViewById(R.id.phone);
        password = (EditText)
                activity.findViewById(R.id.pass);

    }

    public Register helperRegister() {
        Register register = new Register();
        register.setName(name.getText().toString());
        register.setEmail(email.getText().toString());
    }
}
