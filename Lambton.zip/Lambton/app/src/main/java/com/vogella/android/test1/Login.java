package com.vogella.android.test1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity implements View.OnClickListener {

    Button btnlogin;
    Button btnreg;
    Button btnguest;
    EditText edtuser;
    EditText edtpass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);


        btnlogin = findViewById(R.id.btnlogin);
        btnlogin.setOnClickListener(this);

        btnreg = findViewById(R.id.btnreg);
        btnreg.setOnClickListener(this);

        btnguest = findViewById(R.id.btnguest);
        btnguest.setOnClickListener(this);

        edtuser = findViewById(R.id.edtuser);
        edtpass = findViewById(R.id.edtpass);
    }

    @Override

    public void onClick(View view) {

        if (view.getId() == btnlogin.getId()) {
            String username = edtuser.getText().toString();
            String password = edtpass.getText().toString();

            if (username.equals("manjot") && password.equals("asdf")) {
                Toast.makeText(this, "Login Successful", Toast.LENGTH_LONG).show();
                startActivity(new Intent(this, ProductActivity.class));
            } else {
                Toast.makeText(this, "Invalid username/password", Toast.LENGTH_LONG).show();
            }


        } else if (view.getId() == btnguest.getId()) {
            Toast.makeText(this, "Product List", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, ProductActivity.class));
        } else if (view.getId() == btnreg.getId())

        {
            Toast.makeText(this, "Sign Up", Toast.LENGTH_LONG).show();
            Intent SignUpIntent = new Intent(this, Register.class);
            startActivity(SignUpIntent);

        }
    }
}