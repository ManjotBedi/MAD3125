package com.vogella.android.test1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Database extends SQLiteOpenHelper {

    public Database(Context context) {
        super(context, "MyReg", null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase sqldb) {
        String sql = "CREATE TABLE Register(id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT, phone TEXT, password TEXT)";
        sqldb.execSQL(sql);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqldb, int oldVersion, int newVersion) {

        String sql = "DROP TABLE IF EXISTS Register";
        sqldb.execSQL(sql);
        onCreate(sqldb);

    }
}
