package com.vogella.android.test1;

import android.app.ListActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class ProductActivity extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String[] products = new String[] {"Shirts", "Pants", "Shoes", "Accessories"};

        ArrayAdapter adapter = new ArrayAdapter<String>(this, R.layout.productlist, products);
        setListAdapter(adapter);

//        ListView productList = (ListView)
//                findViewById(R.id.p_list);
//        productList.setAdapter(adapter);
    }
}