package com.vogella.android.test1;

public class Register {
}
