package com.sidhufoods.foodatdoor;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class manual extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual);

        WebView webManual=findViewById(R.id.webManual);
       // webManual.loadUrl("https://www.google.com");
        // webManual.loadUrl("https://www.google.com/search?q=Lambton");
        webManual.loadUrl("file://android_asset/foodmanual.html");
    }
}
