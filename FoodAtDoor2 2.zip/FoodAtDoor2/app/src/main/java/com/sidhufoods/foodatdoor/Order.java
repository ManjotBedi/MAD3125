package com.sidhufoods.foodatdoor;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class Order extends AppCompatActivity  implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    Spinner spnFood, spnDrink;
    Button btnOk, btnCancel;

    String Food[] = {"Pizza", "Burger", "Wraps", "Cupcakes"};
    String Drink[] = {"Pepsi", "Coke", "Coffee", "Ice Cap"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        btnOk= findViewById(R.id.btnOk);
        btnOk.setOnClickListener(this);

        btnCancel= findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        spnFood = findViewById(R.id.spnFood);
        ArrayAdapter FoodAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, Food);
        FoodAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnFood.setAdapter(FoodAdapter);
        spnFood.setOnItemSelectedListener(this);

        spnDrink = findViewById(R.id.spnDrink);
        ArrayAdapter DrinkAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, Drink);
        DrinkAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnDrink.setAdapter(DrinkAdapter);
        spnDrink.setOnItemSelectedListener(this);
    }

    @Override
    public void onClick(View view) {


        if (btnOk.getId() == view.getId()) {
            startActivity(new Intent(getApplicationContext(), checkout.class));

        } else if (btnCancel.getId() == view.getId()) {
            finish();
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}


