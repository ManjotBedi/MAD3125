package com.sidhufoods.foodatdoor;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static com.sidhufoods.foodatdoor.DBHelper.*;

public class login extends AppCompatActivity implements View.OnClickListener{

    Button LogInButton;
    EditText email;
    EditText password;
    TextView createAccount;
    DBHelper dbHelper;
    SQLiteDatabase foodatdoorDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        createAccount = findViewById(R.id.createAccount);
        createAccount.setOnClickListener( this);

        LogInButton = findViewById(R.id.LoginButton);
        LogInButton.setOnClickListener( this);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);

        dbHelper = new DBHelper(this);
    }

    public void onClick(View v) {

        if (v.getId() == LogInButton.getId()) {

            String username = email.getText().toString();
            String password1 = password.getText().toString();

            if (verifyLogin()) {
                Toast.makeText(this, "login Successful", Toast.LENGTH_LONG).show();

                finish();
                startActivity(new Intent(this, home.class));
            } else {
                Toast.makeText(this, "Invalid Username/Password", Toast.LENGTH_LONG).show();
            }
            //Toast.makeText(this, "Button Clicked", Toast.LENGTH_LONG).show();
        } else if (v.getId() == createAccount.getId()) {
            Toast.makeText(this, "Creating an account", Toast.LENGTH_LONG).show();

            finish();
            Intent signUpIntent = new Intent(this, signUp.class);
            startActivity(new Intent(getApplicationContext(),signUp.class));
        }
    }

    private boolean verifyLogin() {
        try {
            foodatdoorDB = dbHelper.getReadableDatabase();
            String columns[] = {"Email", "Password"};
            String userData[] = {email.getText().toString(), password.getText().toString()};

            Cursor cursor = foodatdoorDB.query("UserInfo", columns, "email = ? AND password = ?", userData, null, null, null);

            if (cursor != null) {
                if (cursor.getCount() > 0) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            Log.e("LoginActivity", e.getMessage());
            return false;
        } finally {
            foodatdoorDB.close();
        }
    }
}

