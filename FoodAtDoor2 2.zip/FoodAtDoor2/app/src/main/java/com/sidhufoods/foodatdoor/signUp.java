package com.sidhufoods.foodatdoor;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static android.app.ProgressDialog.show;

public class signUp extends AppCompatActivity implements View.OnClickListener {


    EditText entername;
    EditText password;
    EditText creditCard;
    EditText editemail;
    EditText phone;
    DBHelper dbHelper;
    Button signupbutton;
    SQLiteDatabase foodatdoorDB;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        signupbutton=findViewById(R.id.signupbutton);
        signupbutton.setOnClickListener((View.OnClickListener) this);

        entername=findViewById(R.id.entername);
        password=findViewById(R.id.password);
        creditCard=findViewById(R.id.creditCard);
        editemail=findViewById(R.id.editemail);
        phone=findViewById(R.id.phone);

        dbHelper = new DBHelper(this);
    }

    public void onClick(View v) {
        if (v.getId()==signupbutton.getId()){


            insertData();
           // displaydata();
            Intent loginIntent=new Intent(this,login.class);
            startActivity(loginIntent);
        }

    };

    private void insertData(){
        String name = entername.getText().toString();
        String password1 = password.getText().toString();
        String creditcard1 =creditCard.getText().toString();

        String email1 =editemail.getText().toString();
        String phone1 = phone.getText().toString();

        ContentValues cv = new  ContentValues();
        cv.put("Name",name);
        cv.put("Password",password1);
        cv.put("creditCard",creditcard1);
        cv.put("Email", email1);
        cv.put("Phone",phone1);

        try{
            foodatdoorDB = dbHelper.getWritableDatabase();
            foodatdoorDB.insert("UserInfo", null, cv);
            Log.v("SignUp", "AccountCreated");

        }catch (Exception e){
            Log.e("SignUp", e.getMessage());
        }finally {
            foodatdoorDB.close();
        }


    }
    private void displaydata(){
        try{
            foodatdoorDB = dbHelper.getReadableDatabase();
            String columns[] = {"Name","Password","creditCard","Email","Phone"};

            Cursor cursor = foodatdoorDB.query("UserInfo", columns,null,null,null,null,null);

            while (cursor.moveToNext()){
                String UserData = cursor.getString(cursor.getColumnIndex("Name"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Password"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("creditCard"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Email"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Phone"));

                Toast.makeText(this,UserData,Toast.LENGTH_LONG).show();
            }

        }catch (Exception e){
            Log.e("signUp",e.getMessage());
        }finally {
            foodatdoorDB.close();
        }
    }
}



