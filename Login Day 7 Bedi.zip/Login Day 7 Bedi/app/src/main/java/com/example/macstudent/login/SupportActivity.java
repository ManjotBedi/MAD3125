package com.example.macstudent.login;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SupportActivity extends AppCompatActivity implements View.OnClickListener {

    Button btncall, btnsms, btnemail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);


        btncall = findViewById(R.id.btncall);
        btncall.setOnClickListener(this);

        btnsms = findViewById(R.id.btnsms);
        btnsms.setOnClickListener(this);

        btnemail = findViewById(R.id.btnemail);
        btnemail.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        /*if (view.getId() == btncall.getId()) {
        } else if (view.getId() == btnsms.getId()) {

        } else if (view.getId() == btnemail.getId()) {

        }*/
        switch (view.getId()) {
            case R.id.btncall:
                makecall();
                break;
            case R.id.btnsms:
                sendsms();
                break;
            case R.id.btnemail:
                sendemail();
                break;

        }
    }

    private void makecall() {
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:4165299838"));

        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getApplicationContext(), "Call Permission Denied", Toast.LENGTH_LONG).show();
            return;
        }


        startActivity(callIntent);


    }

    private void sendsms() {

        Intent smsIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:4165299838"));
        smsIntent.putExtra("sms_body", "This is test message");
        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getApplicationContext(), "sms Permission Denied", Toast.LENGTH_LONG).show();
            return;}

            startActivity(smsIntent);

        }


    private void sendemail() {

        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"manjotkkbedi@gmail.com", "harman@gmail.com"});

        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Test Email");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "this is test message");
        emailIntent.setType("*/*");

        startActivity(Intent.createChooser(emailIntent, "Select email account"));
    }
}



